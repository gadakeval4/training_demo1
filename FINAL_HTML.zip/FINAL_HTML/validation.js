// function check_pass() {
//     if (document.getElementById('password').value ==
//             document.getElementById('confirm_password').value) {
//         document.getElementById('submit').disabled = false;
//     } else {
       
//         document.getElementById('submit').disabled = true;
        
//     }
// }

function passwordcheck()
{
    if(document.getElementById('pwd').value !=
    document.getElementById('cpwd').value)
    {
        window.alert("Password Do not Match");
    }
}
